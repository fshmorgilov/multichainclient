package com.themaker.fshmo.klassikaplus.data.persistence.dao;

public interface ItemDao {
}
