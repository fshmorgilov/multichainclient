package com.themaker.fshmo.klassikaplus.data.persistence.model;

public class DbItem {
}
