package com.themaker.fshmo.klassikaplus.dagger;

import dagger.Component;

import javax.inject.Singleton;

@Singleton
@Component
public interface AppComponent {
}
