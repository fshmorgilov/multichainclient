package com.themaker.fshmo.klassikaplus.data.repositories;

public abstract class BaseRepository  {

}